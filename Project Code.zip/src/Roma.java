import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 * User: nayyarv
 * Date: 10/03/12
 * Time: 9:59 PM
 * To change this template use File | Settings | File Templates.
 */

public class Roma {
    public static void main(String[] args) {
        System.out.println("Bye");
        clientInterface.welcome();
        cleanScreen();



    }

    public static boolean yesNo(){
        Scanner input = new Scanner( System.in );
        String line = input.nextLine();
        System.out.println(line);
        boolean yes = false;
        if(line.charAt(0)=='Y'||line.charAt(0)=='y') yes=true;
        return yes;
        //while (scanner.hasNextLine()) {
        // process the line
        //}
        //
    }

    public static void cleanScreen() {

        for (int i = 0; i < 2; i++) {
            System.out.println();

        }


    }
}
